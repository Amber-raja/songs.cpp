#include "Favourite_Songs.h"

#include <iostream>
#include <algorithm>

Favourite_Songs::Favourite_Songs(int size) : size(size), songs(new std::string[size]) {}

Favourite_Songs::Favourite_Songs(const Favourite_Songs& other) : size(other.size), songs(new std::string[other.size]) {
    std::copy(other.songs, other.songs + other.size, songs);
}

Favourite_Songs::~Favourite_Songs() {
    delete[] songs;
}

void Favourite_Songs::addSong(const std::string& song) {
    std::string* newSongs = new std::string[size + 1];
    std::copy(songs, songs + size, newSongs);
    newSongs[size] = song;
    delete[] songs;
    songs = newSongs;
    size++;
}

void Favourite_Songs::deleteSong(const std::string& song) {
    std::string* newSongs = new std::string[size - 1];
    int j = 0;
    for (int i = 0; i < size; i++) {
        if (songs[i] != song) {
            newSongs[j] = songs[i];
            j++;
        }
    }
    delete[] songs;
    songs = newSongs;
    size--;
}

void Favourite_Songs::updateSong(const std::string& oldSong, const std::string& newSong) {
    for (int i = 0; i < size; i++) {
        if (songs[i] == oldSong) {
            songs[i] = newSong;
        }
    }
}

void Favourite_Songs::printSongs() const {
    for (int i = 0; i < size; i++) {
        std::cout << songs[i] << std::endl;
    }
}
