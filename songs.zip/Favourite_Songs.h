#ifndef FAVOURITE_SONGS_H
#define FAVOURITE_SONGS_H

#include <string>

class Favourite_Songs {
public:
    Favourite_Songs(int size);
    Favourite_Songs(const Favourite_Songs& other);
    ~Favourite_Songs();
    void addSong(const std::string& song);
    void deleteSong(const std::string& song);
    void updateSong(const std::string& oldSong, const std::string& newSong);
    void printSongs() const;

private:
    int size;
    std::string* songs;
};

#endif // FAVOURITE_SONGS_H
