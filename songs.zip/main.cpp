#include <iostream>
#include <string>
#include "Favourite_Songs.h"
using namespace std;

int main() {
    Favourite_Songs song(4);
   
    int choice;
    string S;
    string oldS;
    string newS;
    
    while(1) {
        cout << "1. Add a song" << endl <<"2. Update a song" << endl << "3. Delete a song" << endl <<"4. Print songs" << endl <<"5. Create backup of songs" << endl;
        cin >> choice;

        if (choice == 1) {
            cout << "Enter the name of new song: " << endl;
            cin >> S;
            song.addSong(S);
        }
        else if (choice == 2) {
            cout << "Enter the name of the song you want to update: " << endl;
            cin >> oldS;
            cout << "Enter the new name of the song: " << endl;
            cin >> newS;
            song.updateSong(oldS, newS);
        }
        else if (choice == 3) {
            cout << "Enter the name of the song you want to delete: " << endl;
            string s2;
            cin >> s2;
            song.deleteSong(s2);
        }
        else if (choice == 4) {
            song.printSongs();
        }
        else if (choice == 5) {
            Favourite_Songs song2(song);
            song2.printSongs();
        }
        else {
            break;
        }
    }

    return 0;
}
